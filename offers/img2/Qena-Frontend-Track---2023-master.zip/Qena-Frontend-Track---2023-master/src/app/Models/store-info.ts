export interface StoreInfo {
    name:string,
    coverImg:string,
    branches:string[]
}
