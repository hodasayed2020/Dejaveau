export class DataClass {
    // name:string;
    // constructor(_name:string){
    //     this.name=_name;
    // }

    // Another way
    // name:string;
    constructor(public name:string,
                public imgURL:string,
                public branches:string[]){
        // this.name=_name;
    }
}
